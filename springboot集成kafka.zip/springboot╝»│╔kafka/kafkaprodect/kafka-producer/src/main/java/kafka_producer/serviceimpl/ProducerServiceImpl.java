package kafka_producer.serviceimpl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import kafka_producer.dao.ProducerDao;
import kafka_producer.entity.ProducerEntity;
import kafka_producer.service.ProducerService;
@Service
public class ProducerServiceImpl implements ProducerService {
	@Autowired
	private ProducerDao producerDao;
	@Override
	public List<ProducerEntity> selectService(String name) {
		
		return producerDao.selectDao(name);
	}

}
