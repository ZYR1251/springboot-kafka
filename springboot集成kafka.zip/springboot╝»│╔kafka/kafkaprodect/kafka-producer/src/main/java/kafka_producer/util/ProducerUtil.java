package kafka_producer.util;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;
@Component
public class ProducerUtil {
	@Autowired
	private KafkaTemplate<String, String> kafkaTemplate;
	public void send(String topic ,String message) {
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//设置日期格式
		try {
			kafkaTemplate.send(topic,message);
			System.out.println("消息发送成功：" + message);
			System.out.println("当前时间: "+df.format(new Date()));
			System.out.println("----------");
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("消息发送失败：" + message);
			System.out.println("当前时间: "+df.format(new Date()));
			System.out.println("----------");
		}
	}
}