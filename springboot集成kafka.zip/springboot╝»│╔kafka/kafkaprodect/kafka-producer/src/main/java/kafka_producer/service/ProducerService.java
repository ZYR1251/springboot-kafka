package kafka_producer.service;

import java.util.List;

import kafka_producer.entity.ProducerEntity;

public interface ProducerService {
	List<ProducerEntity> selectService(String name);
}
