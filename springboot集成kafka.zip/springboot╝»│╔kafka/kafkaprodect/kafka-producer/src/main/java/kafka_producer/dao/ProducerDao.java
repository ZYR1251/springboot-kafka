package kafka_producer.dao;

import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import kafka_producer.entity.ProducerEntity;
@Mapper
public interface ProducerDao {
	@Select("select * from producer where name=#{name}")
	List<ProducerEntity> selectDao(String name); 
}
