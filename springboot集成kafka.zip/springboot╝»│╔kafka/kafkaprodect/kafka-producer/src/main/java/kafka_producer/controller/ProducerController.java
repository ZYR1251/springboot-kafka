package kafka_producer.controller;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.codehaus.jackson.map.ObjectMapper;
import kafka_producer.entity.ProducerEntity;
import kafka_producer.service.ProducerService;
import kafka_producer.util.ProducerUtil;

@RestController
@RequestMapping(value = "/api")
public class ProducerController {
	@Autowired
	private ProducerService producerService;
	@Autowired 
	private ProducerUtil producerUtil;
	@GetMapping(value = "/producer")
	public List<ProducerEntity> selectController(@RequestParam(value = "name",required = true) String name) throws IOException{
		System.out.println("开始查询信息……");
		List<ProducerEntity> result=producerService.selectService(name);
		String jsonResult=new ObjectMapper().writeValueAsString(result);
		producerUtil.send("kafka-YL", jsonResult);
		return result;
	}
}
