package com.kafka.prodect.serviceimpl;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.kafka.prodect.dao.DeptDao;
import com.kafka.prodect.entity.Dept;
import com.kafka.prodect.service.DeptService;

@Service
public class DeptServiceImpl implements  DeptService{
	@Autowired
	private DeptDao deptDao;
	  @Override
	    public List<Dept> findById(String id) { 
		   return deptDao.findById(id);
	       	    }
}
