package com.kafka.prodect.service;

import java.util.List;

import com.kafka.prodect.entity.Dept;

public interface DeptService {
	List<Dept> findById(String id);

}
