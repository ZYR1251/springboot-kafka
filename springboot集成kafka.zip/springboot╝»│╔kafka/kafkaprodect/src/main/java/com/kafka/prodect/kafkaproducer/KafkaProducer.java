package com.kafka.prodect.kafkaproducer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.stereotype.Component;


/**
 * 生产者
 * 使用@EnableScheduling注解开启定时任务
 */
 @Component 
 @EnableScheduling 
public class KafkaProducer {

    @Autowired
    private KafkaTemplate kafkaTemplate;//KafkaTemplate这个类包装了个生产者，来提供方便的发送数据到kafka的topic里面

    /**
     * 定时任务？
     */
	
	public void send(String topic,String message){
        try {
			kafkaTemplate.send(topic,message);
			System.out.println("消息发送成功：" + message);
		} catch (Exception e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
			System.out.println("消息发送失败：" + message);
		}
		/*
		 * future.addCallback(o -> System.out.println("消息发送成功：" + message), throwable ->
		 * System.out.println("消息发送失败：" + message));
		 */
    }
}

