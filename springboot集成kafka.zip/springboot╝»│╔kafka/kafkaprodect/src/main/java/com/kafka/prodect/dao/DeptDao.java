package com.kafka.prodect.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import com.kafka.prodect.entity.Dept;

@Mapper
public interface DeptDao {
	@Select("SELECT id,name,age FROM dept where id=#{id}")
	   List<Dept> findById(String id);

}
