package com.kafka.prodect.controller;

import java.io.IOException;
import java.util.List;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.kafka.prodect.dao.DeptDao;
import com.kafka.prodect.entity.Dept;
import com.kafka.prodect.kafkaproducer.KafkaProducer;
import com.kafka.prodect.service.DeptService;

@RestController
@RequestMapping(value="/main")
public class DeptController {
	@Autowired
	private KafkaProducer kafkaProducer;
	@Autowired
	private DeptService deptService;
	@Autowired
	private DeptDao deptDao;
	@RequestMapping(value = "/findbyid", method = RequestMethod.GET)
    public List<Dept> findByUserId(@RequestParam(value = "id", required = true) String id)
			throws IOException  {
		System.out.println("数据开始传入kafka");	
		  List<Dept> result = deptDao.findById(id);	 
		//ObjectMapper类是Jackson库的主要类。它提供一些功能将转换成Java对象匹配JSON结构,反之亦然
		  ObjectMapper om = new ObjectMapper();	
		//writeValueAsString把对象转化为Json字符串
		  String jsonResult = om.writeValueAsString(result);	
		//send只能把字符串类型的数据写入到kafka
		  kafkaProducer.send("KAFKA_TESTZYR",jsonResult);		 
		return deptService.findById(id);		
	}
}
