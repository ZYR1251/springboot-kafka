package kafka_consumer.dao;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
@Mapper
public interface ConsumerDao {
	@Insert("insert into consumer(id,name,age) values(#{arg0},#{arg1},#{arg2})")
	void insertDao(int id,String name,int age);
}
