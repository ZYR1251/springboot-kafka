package kafka_consumer.serviceimpl;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import kafka_consumer.dao.ConsumerDao;
import kafka_consumer.service.ConsumerService;
@Service
public class ConsumerServiceImpl implements ConsumerService{
	@Autowired
	private ConsumerDao consumerDao;
	@Override
	public void insertService(int id,String name,int age) {
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//设置日期格式
		try {
			consumerDao.insertDao(id,name,age);
			System.out.println("数据写入成功！");
			System.out.println("当前时间: "+df.format(new Date()));
			System.out.println("----------");
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("数据写入失败！");
			System.out.println("当前时间: "+df.format(new Date()));
			System.out.println("----------");
		}
	}

}