package kafka_consumer.service;

public interface ConsumerService {
	void insertService(int id,String name,int age); 
}