package com.kafka.service;



public interface DcallService {
	public void Insert(String id,String age,String name);
	}

   

