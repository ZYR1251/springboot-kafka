package com.kafka.consumer;


import java.io.IOException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kafka.entity.Dcall;
import com.kafka.service.DcallService;


/**
 * 消费者
 * 使用@KafkaListener注解,可以指定:主题,分区,消费组
 */
@Component

public class KafkaConsumer {
	
	@Autowired 
	  private ObjectMapper objectMapper;//ObjectMapper类是Jackson库的主要类。它提供一些功能将转换成Java对象匹配JSON结构，反之亦然。
	 @Autowired
	 private DcallService dcallService;
	//在方法上使用@KafkaListener注解，并指定要消费的topic（也可以指定消费组以及分区号，支持正则表达式匹配），这样，消费者一旦启动，就会监听kafka服务器上的topic，实时进行消费消息
	 @KafkaListener(topics = {"KAFKA_TESTZYR"})
	 public void receive(String message) throws JsonMappingException,
	 IOException{
   //读取生产者的所有数据并进行格式转换（jsonstring-json对象）
		 Dcall dcall = objectMapper.readValue(message, Dcall[].class)[0];
		 dcallService.Insert(dcall.getId(),dcall.getAge(),dcall.getName());	 
		 
	 }
}
