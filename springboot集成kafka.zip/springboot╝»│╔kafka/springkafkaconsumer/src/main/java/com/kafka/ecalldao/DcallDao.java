package com.kafka.ecalldao;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;


@Mapper
public interface DcallDao {
	@Insert("INSERT into dept1(id,age,name) values (#{arg0},#{arg1},#{arg2})")     
	public void Insert(String id,String age,String name);
}
