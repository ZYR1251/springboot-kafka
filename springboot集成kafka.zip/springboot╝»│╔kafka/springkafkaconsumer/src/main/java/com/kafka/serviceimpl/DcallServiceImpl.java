package com.kafka.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kafka.ecalldao.DcallDao;
import com.kafka.entity.Dcall;
import com.kafka.service.DcallService;


@Service
public class DcallServiceImpl implements DcallService{
	@Autowired
 private Dcall ecall;
	@Autowired
	private DcallDao dcallDao;
	@Override
	public void Insert(String id,String age,String name)
	  {
		  String result = "写入mysql成功";
		  try {
			   dcallDao.Insert(id,age,name); //dcallResult;	
			  System.out.println("写入mysql成功");
		} catch (Exception e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
			System.out.println("写入mysql失败");
			result = "写入mysql失败";
		}
		}
}
